# Kotlin package and file naming — Step 30

The Android source tree uses Kotlin-first naming. File names match their primary
Kotlin type where practical, and the former migration-era/helper names are gone
from the active source tree.

```text
com.socialnetwork.app
├── core/
│   ├── AppConstants.kt
│   ├── AppExecutors.kt
│   ├── AppUtils.kt
│   ├── AuthUtils.kt
│   ├── ConnectivityMonitor.kt
│   ├── FeatureFlags.kt
│   ├── OfflineSyncCoordinator.kt
│   └── SecretStore.kt
│
├── data/
│   ├── local/
│   │   └── OfflineStore.kt
│   └── model/
│       ├── HttpResult.kt
│       ├── OfflineException.kt
│       └── UploadedMedia.kt
│
├── features/
│   └── FeatureRegistry.kt
│
├── network/
│   ├── ServiceClients.kt
│   └── ServiceEndpoints.kt
│
└── ui/
    └── MainActivity.kt
```

## Naming rules

- Kotlin source files use `PascalCase.kt` matching the main type.
- Generic migration-era prefixes such as `Kotlin*` and `*Legacy` are not used in
  the active Android source tree.
- Model types with separate responsibilities live in separate files.
- Android entry points remain named after their component (`MainActivity.kt`).
