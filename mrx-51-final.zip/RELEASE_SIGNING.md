# Release signing for mr.x

The project now has a real release-signing configuration, but **private signing material is intentionally not included** in the source ZIP.

## Local release build

1. Make sure JDK 17+ is installed.
2. Create an upload keystore once:

```bash
bash tools/create-upload-keystore.sh
```

3. Copy the template:

```bash
cp keystore.properties.example keystore.properties
```

4. Put the keystore path, store password, alias, and key password into `keystore.properties`.
5. Build:

```bash
./gradlew :app:bundleRelease
```

The build will stop early with a clear error if release signing is not configured.

## CI / GitHub Actions

Do not commit the keystore or passwords. Supply these as protected CI secrets/environment variables:

- `MRX_RELEASE_STORE_FILE`
- `MRX_RELEASE_STORE_PASSWORD`
- `MRX_RELEASE_KEY_ALIAS`
- `MRX_RELEASE_KEY_PASSWORD`

`MRX_RELEASE_STORE_FILE` must point to a keystore that the CI job has securely materialized before Gradle runs.

## Existing Google Play app

If `mr.x` is already published, do **not** generate a replacement signing key blindly. The app update must use the correct existing signing identity. With Google Play App Signing, keep the Play App Signing key managed by Google and use the configured upload key for uploads. If you are changing an upload key, follow the Play Console key-reset procedure rather than replacing files in this repository.

## Security rules

- `keystore.properties`, `*.jks`, `*.keystore`, and `*.p12` are ignored by Git.
- Never put passwords in `app/build.gradle.kts`.
- Never put a private keystore in a public source ZIP.
- Keep at least one secure offline backup of the release/upload keystore and its passwords.
