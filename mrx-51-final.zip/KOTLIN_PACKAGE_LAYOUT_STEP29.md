# Kotlin Package Layout — Step 29

The Android source is organized by responsibility instead of keeping every class in one package.

```text
app/src/main/kotlin/com/socialnetwork/app/
├── core/
│   ├── AppConstants.kt
│   ├── AppExecutors.kt
│   ├── ConnectivityMonitor.kt
│   ├── FeatureFlags.kt
│   ├── AuthUtils.kt
│   ├── AppUtils.kt
│   ├── OfflineSyncCoordinator.kt
│   └── SecretStore.kt
├── data/
│   ├── local/
│   │   └── OfflineStore.kt
│   └── model/
│       └── HttpResult.kt
├── features/
│   └── FeatureRegistry.kt
├── network/
│   ├── ServiceClients.kt
│   └── ServiceEndpoints.kt
└── ui/
    ├── MainActivity.kt
    └── MainActivity.kt
```

`MainActivity` remains the manifest entry point; the the activity implementation lives directly in `MainActivity` to keep UI entry wiring separate from the large screen implementation during the migration.
