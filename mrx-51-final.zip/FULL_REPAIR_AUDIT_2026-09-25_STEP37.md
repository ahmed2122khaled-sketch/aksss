# mr.x Full Repair Audit — Step 37 (2026-09-25)

## Scope
- Re-audited the full Kotlin-only Android source tree and build configuration.
- Fixed the Android build plugin version mismatch: AGP 9.3.1 + Kotlin 2.4.20 + Gradle 9.7.1.
- Hardened service routing so every configured HTTPS service origin can be safely normalized/routed without relying on primary-origin assumptions.
- Fixed read-replica transport-failure fallback so a failed replica can fall back to the write endpoint before surfacing the error.
- Centralized storage object URL construction through the storage client.
- Bumped app version to 2.19.3 / versionCode 48.

## Security / regression intent
- No Java source files.
- No WebView/browser shell.
- HTTPS-only endpoints remain enforced.
- Redirect following remains disabled.
- Storage/media URLs remain constrained to the configured storage origin and media path.
- Existing request/response body limits, offline account binding, upload cleanup, retry guards, and lifecycle checks are preserved.

## Verification
All repository static verifiers are expected to pass. A full Android build is still environment-dependent when the Android SDK/toolchain is not installed.
