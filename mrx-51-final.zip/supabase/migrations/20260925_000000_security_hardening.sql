-- mr.x security hardening for the existing 2026 schema.
-- Keeps user-editable fields writable while preventing client-side tampering
-- with ownership, counters, verification state, timestamps, and message authorship.

create or replace function public.protect_profile_system_fields()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  new.id := old.id;
  new.is_verified := old.is_verified;
  new.followers_count := old.followers_count;
  new.following_count := old.following_count;
  new.posts_count := old.posts_count;
  new.created_at := old.created_at;
  return new;
end;
$$;

drop trigger if exists protect_profile_system_fields on public.profiles;
create trigger protect_profile_system_fields
before update on public.profiles
for each row execute function public.protect_profile_system_fields();

create or replace function public.protect_post_system_fields()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  new.id := old.id;
  new.user_id := old.user_id;
  new.likes_count := old.likes_count;
  new.comments_count := old.comments_count;
  new.created_at := old.created_at;
  return new;
end;
$$;

drop trigger if exists protect_post_system_fields on public.posts;
create trigger protect_post_system_fields
before update on public.posts
for each row execute function public.protect_post_system_fields();

create or replace function public.protect_story_system_fields()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  new.id := old.id;
  new.user_id := old.user_id;
  new.views_count := old.views_count;
  new.created_at := old.created_at;
  return new;
end;
$$;

drop trigger if exists protect_story_system_fields on public.stories;
create trigger protect_story_system_fields
before update on public.stories
for each row execute function public.protect_story_system_fields();

create or replace function public.protect_message_system_fields()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  new.id := old.id;
  new.conversation_id := old.conversation_id;
  new.sender_id := old.sender_id;
  new.created_at := old.created_at;
  return new;
end;
$$;

drop trigger if exists protect_message_system_fields on public.messages;
create trigger protect_message_system_fields
before update on public.messages
for each row execute function public.protect_message_system_fields();

create or replace function public.protect_notification_system_fields()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  new.id := old.id;
  new.user_id := old.user_id;
  new.type := old.type;
  new.actor_id := old.actor_id;
  new.post_id := old.post_id;
  new.comment_id := old.comment_id;
  new.created_at := old.created_at;
  return new;
end;
$$;

drop trigger if exists protect_notification_system_fields on public.notifications;
create trigger protect_notification_system_fields
before update on public.notifications
for each row execute function public.protect_notification_system_fields();

-- A conversation member may read a message, but only its sender may edit/delete it.
drop policy if exists messages_update on public.messages;
create policy messages_update on public.messages
for update to authenticated
using (sender_id = auth.uid())
with check (sender_id = auth.uid() and public.is_conversation_member(messages.conversation_id, auth.uid()));

drop policy if exists messages_delete on public.messages;
create policy messages_delete on public.messages
for delete to authenticated
using (sender_id = auth.uid());
