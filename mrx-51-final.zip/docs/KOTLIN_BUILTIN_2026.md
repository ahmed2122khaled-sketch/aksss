# Mr.x Kotlin / AGP 2026 Toolchain

- Android Gradle Plugin: 9.3.2
- Gradle Wrapper distribution: 9.7.1
- Java runtime for CI: JDK 17
- compileSdk: 37
- targetSdk: 37
- minSdk: 21
- Kotlin mode: AGP 9+ Built-in Kotlin
- Built-in Kotlin Gradle Plugin baseline for AGP 9.x: Kotlin 2.2.10

Do not add `org.jetbrains.kotlin.android` merely to declare a separate Kotlin version when using AGP 9+ Built-in Kotlin. Any deliberate override must be reviewed against the AGP/Kotlin compatibility matrix before changing this baseline.

Wrapper JAR integrity reference (Gradle official release checksums):
`7a9ce74cff467ca1bf60a4fcd9f05185acceda4d0f382434d393e17864262c5d`

Wrapper distribution SHA-256:
`acd53f1edaf02f1a8ff99879f8a34b302661a057d9b063ae9e35b552f804d20a`
