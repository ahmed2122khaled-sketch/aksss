# Build Compatibility — 2026-09-25

Current Step 45 R4 toolchain baseline:
- Android Gradle Plugin: 9.3.2
- Built-in Kotlin / Kotlin Gradle Plugin: 2.2.10 (AGP 9.x built-in Kotlin baseline)
- Gradle wrapper: 9.7.1
- compileSdk / targetSdk: 37
- minSdk: 21
- JDK: 17
- Android SDK Build Tools: 36.0.0 (AGP 9.3 default)

AGP 9.3 officially supports API 37, JDK 17, and Build Tools 36.0.0. The project does not declare `buildToolsVersion` in `app/build.gradle.kts`, so CI and local bootstrap use the documented AGP 9.3 default rather than forcing 37.0.0.

The project uses AGP 9.x Built-in Kotlin; it does not apply the legacy `org.jetbrains.kotlin.android` plugin. Do not document Kotlin 2.4.20 as the project's configured Kotlin version unless a future build explicitly opts out of Built-in Kotlin and pins a separate KGP.

Sources: Android Developers AGP 9.3 release notes (2026-07), Gradle checksum reference/current documentation (2026-09-25).
