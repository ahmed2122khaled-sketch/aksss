# Kotlin Migration — Step 4

This step moves the Android connectivity lifecycle out of `MainActivityLegacy.java` into the Kotlin class `core/KotlinConnectivityMonitor.kt`.

Migrated behavior:
- Network availability detection with API 21+ compatibility.
- Default network callback on API 24+ and NetworkRequest callback on API 21–23.
- Connectivity change callbacks back to the Activity.
- Registration/unregistration lifecycle.
- System bar configuration moved to `KotlinAppUtils.configureSystemBars`.
- Removed the duplicate connectivity registration call from `onCreate`.

`MainActivityLegacy.kt` is now the migrated implementation; the Java source was retained only in earlier checkpoints as the compatibility host while larger UI/network/auth sections are migrated safely.

Build verification note: the local Gradle wrapper could not download Gradle because this environment has no network access (`UnknownHostException: services.gradle.org`). Therefore this checkpoint is not claimed as a verified APK build.
