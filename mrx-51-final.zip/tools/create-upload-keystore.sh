#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
KEYSTORE_PATH="${1:-$ROOT_DIR/release-upload-key.jks}"
KEY_ALIAS="${2:-mrx-upload}"

if [[ -e "$KEYSTORE_PATH" ]]; then
  echo "Keystore already exists: $KEYSTORE_PATH"
  echo "Refusing to overwrite an existing key." >&2
  exit 1
fi

if ! command -v keytool >/dev/null 2>&1; then
  echo "keytool was not found. Install/use JDK 17+ first." >&2
  exit 1
fi

mkdir -p "$(dirname "$KEYSTORE_PATH")"

echo "Creating a NEW upload keystore at: $KEYSTORE_PATH"
echo "IMPORTANT: If this app is already published, do NOT replace its existing signing/upload key without checking Google Play App Signing first."
echo

keytool -genkeypair \
  -v \
  -keystore "$KEYSTORE_PATH" \
  -alias "$KEY_ALIAS" \
  -keyalg RSA \
  -keysize 4096 \
  -validity 10000 \
  -storetype PKCS12 \
  -sigalg SHA256withRSA

echo
echo "Keystore created. Copy keystore.properties.example to keystore.properties and enter the same passwords/alias."
echo "Back up the keystore and its passwords securely. Do not put them in Git or the ZIP you upload publicly."
