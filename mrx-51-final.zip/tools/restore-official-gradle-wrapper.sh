#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
JAR="$ROOT/gradle/wrapper/gradle-wrapper.jar"
EXPECTED="7a9ce74cff467ca1bf60a4fcd9f05185acceda4d0f382434d393e17864262c5d"
URL="https://raw.githubusercontent.com/gradle/gradle/v9.7.1/gradle/wrapper/gradle-wrapper.jar"
TMP="$(mktemp)"
trap 'rm -f "$TMP"' EXIT

command -v curl >/dev/null || { echo "curl is required" >&2; exit 1; }

echo "Downloading official Gradle 9.7.1 Wrapper JAR..."
curl --fail --silent --show-error --location --retry 3 --output "$TMP" "$URL"
ACTUAL="$(sha256sum "$TMP" | awk '{print tolower($1)}')"
if [[ "$ACTUAL" != "$EXPECTED" ]]; then
  echo "ERROR: downloaded Wrapper JAR checksum mismatch" >&2
  echo "Expected: $EXPECTED" >&2
  echo "Actual:   $ACTUAL" >&2
  exit 1
fi
install -m 0644 "$TMP" "$JAR"
printf '%s  %s\n' "$ACTUAL" "$JAR"
echo "Official Gradle 9.7.1 Wrapper JAR installed and verified."
