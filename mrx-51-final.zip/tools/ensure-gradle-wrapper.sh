#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
JAR="$ROOT/gradle/wrapper/gradle-wrapper.jar"
EXPECTED="7a9ce74cff467ca1bf60a4fcd9f05185acceda4d0f382434d393e17864262c5d"
if [ -s "$JAR" ]; then
  ACTUAL="$(sha256sum "$JAR" | awk '{print tolower($1)}')"
  if [ "$ACTUAL" = "$EXPECTED" ]; then exit 0; fi
  echo "ERROR: existing Gradle Wrapper JAR checksum mismatch; refusing to execute it." >&2
  echo "Expected: $EXPECTED" >&2
  echo "Actual:   $ACTUAL" >&2
  rm -f "$JAR"
fi
"$ROOT/tools/fetch-gradle-wrapper.sh"
