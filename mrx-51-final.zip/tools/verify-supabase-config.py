#!/usr/bin/env python3
from pathlib import Path
from urllib.parse import urlparse
import os, re, sys

ROOT = Path(__file__).resolve().parents[1]
props = ROOT / "supabase.properties"
example = ROOT / "supabase.properties.example"

if not props.exists():
    print("[INFO] supabase.properties is not committed; configure it locally or use CI environment variables.")
    sys.exit(0)

def load(path):
    out = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        line=line.strip()
        if not line or line.startswith('#') or '=' not in line: continue
        k,v=line.split('=',1); out[k.strip()]=v.strip()
    return out

cfg=load(props)
errors=[]
url=cfg.get('SUPABASE_URL','')
key=cfg.get('SUPABASE_PUBLISHABLE_KEY','')
if not url: errors.append('SUPABASE_URL is empty')
u=urlparse(url)
if url and (u.scheme.lower()!='https' or not u.hostname or u.username or u.password or u.query or u.fragment or u.path not in ('','/')):
    errors.append('SUPABASE_URL must be an HTTPS origin such as https://PROJECT_REF.supabase.co')
if 'YOUR_PROJECT_REF' in url or 'YOUR_PROJECT' in url: errors.append('SUPABASE_URL still contains a placeholder')
if not key or 'YOUR_PUBLIC' in key or key.lower() in ('xxx','changeme'): errors.append('SUPABASE_PUBLISHABLE_KEY is missing or still a placeholder')
for name in ('SUPABASE_DATA_READ_URL','SUPABASE_DATA_WRITE_URL','SUPABASE_AUTH_URL','SUPABASE_STORAGE_URL'):
    value=cfg.get(name,'')
    if not value: continue
    x=urlparse(value)
    if x.scheme.lower()!='https' or not x.hostname or x.username or x.password or x.query or x.fragment or x.path not in ('','/'):
        errors.append(f'{name} must be an HTTPS origin')
if any(k.startswith('SUPABASE_') and ('service_role' in v.lower() or v.lower().startswith('sb_secret_')) for k,v in cfg.items()):
    errors.append('A secret/service-role key must never be shipped in the Android app')

if errors:
    for e in errors: print('[FAIL]', e)
    sys.exit(1)
print('[PASS] Supabase URL/key configuration is structurally valid (secret value not printed).')
