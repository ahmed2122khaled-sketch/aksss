$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$Jar = Join-Path $Root 'gradle\wrapper\gradle-wrapper.jar'
$Expected = '7a9ce74cff467ca1bf60a4fcd9f05185acceda4d0f382434d393e17864262c5d'
if (Test-Path $Jar) {
    $actual = (Get-FileHash $Jar -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($actual -eq $Expected) { exit 0 }
    Write-Error "Existing Gradle Wrapper JAR checksum mismatch. Expected $Expected, actual $actual"
    Remove-Item $Jar -Force
}
& (Join-Path $Root 'tools\fetch-gradle-wrapper.ps1')
