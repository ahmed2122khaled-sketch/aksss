# Built-in Kotlin baseline — 2026

The Mr.x Android build uses Android Gradle Plugin 9.3.2 with AGP 9.x Built-in Kotlin. The project does **not** apply `org.jetbrains.kotlin.android`.

For AGP 9.x, the documented Kotlin Gradle Plugin baseline is Kotlin 2.2.10. This is the version to use when describing the project's built-in Kotlin toolchain; `Kotlin 2.4.20` is not configured in this repository.

Do not add the legacy Kotlin Android plugin merely to declare a newer Kotlin version. Any move to an independently pinned KGP must be treated as a deliberate compatibility change and verified against the corresponding AGP/Gradle compatibility documentation.
