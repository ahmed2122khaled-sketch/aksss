# Kotlin Package Layout — Step 35

The Android source tree is organized by responsibility using Kotlin package conventions.

- `core/` — application-wide constants, executors, connectivity and feature flags.
- `auth/` — authentication-specific helpers.
- `security/` — Android Keystore/session secret implementation.
- `util/` — reusable, stateless application utilities.
- `data/local/` — local persistence and offline queue.
- `data/model/` — transport/domain data models and exceptions.
- `sync/` — offline synchronization orchestration.
- `features/` — feature registration and feature-level metadata.
- `network/` — service endpoints and HTTP/service clients.
- `ui/` — Android UI entry points and screens.

No Java source is used by the Android application. The physical path and Kotlin `package` declaration now match for every `.kt` source file.
