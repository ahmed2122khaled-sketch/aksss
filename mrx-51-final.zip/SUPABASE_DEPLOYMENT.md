# mr.x — Supabase deployment

This repository now contains a reproducible database foundation under `supabase/migrations/`.

## 1. Create the Supabase project

Create a new Supabase project, then obtain its project URL and publishable key.
Do not put a service-role key in the Android application.

## 2. Configure the Android app

Copy `supabase.properties.example` to `supabase.properties` and fill in:

- `SUPABASE_URL`
- `SUPABASE_PUBLISHABLE_KEY`
- optional `SUPABASE_DATA_READ_URL`
- optional `SUPABASE_DATA_WRITE_URL`
- optional `SUPABASE_AUTH_URL`
- optional `SUPABASE_STORAGE_URL`

`supabase.properties` is intentionally ignored by Git.

For CI, the same names can be supplied as environment variables (`SUPABASE_URL`, `SUPABASE_PUBLISHABLE_KEY`, and the optional service URLs); environment variables take precedence over the local file.

## 3. Apply migrations

With the Supabase CLI linked to your project, apply the migrations from this repository. The initial migration creates the tables, indexes, RLS policies, profile creation trigger, direct-message RPC, notification/counter triggers, and the `media` Storage bucket.

```bash
supabase login
supabase link --project-ref YOUR_PROJECT_REF
supabase db push
```

Before production deployment, review the generated SQL against your existing project if the remote database already contains tables. Supabase tracks migration history separately from the Git files, so do not bypass migrations by changing the remote schema directly.

## 4. Verify the Android Supabase configuration

Run:

```bash
python3 tools/verify-supabase-config.py
```

This checks the URL shape and rejects placeholder/secret keys without printing credential values.

## 5. Email recovery

Follow `SUPABASE_MRX_EMAIL_SETUP.md` and keep `mrx://auth/callback` in the Auth redirect URLs.

## 6. Storage

The Android client uploads to the `media` bucket under paths such as:

```text
<user-uuid>/posts/<uuid>.<ext>
<user-uuid>/stories/<uuid>.<ext>
```

The migration makes the bucket public for media URLs while restricting authenticated uploads, updates, and deletes to the user's first path segment.

## 7. Verify

Run the repository's static checks before shipping:

```bash
python verify-project.py
python verify-completeness.py
python tools/verify-security.py
python tools/verify-regression.py
```

Then use the provided bootstrap/build scripts on a machine with network access and the Android SDK.

## Configured Android project URL
The Android project is configured for:
`https://brvtmxfatmncfwjnfed.supabase.co`

The Supabase publishable key is intentionally not embedded until it is supplied. Never place a `service_role` or `sb_secret_*` key in the APK.
