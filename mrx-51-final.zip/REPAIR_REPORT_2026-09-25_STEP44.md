# mr.x — Step 44 Compatibility Expansion

## Goal
Expand device compatibility without downgrading the 2026 Android toolchain or reopening security issues.

## Changes
- Kept `minSdk = 21` as the lowest practical supported API for the current AndroidX Activity 1.13.0 Activity Result stack.
- Kept `targetSdk = 37` and `compileSdk = 37` for Android 17 compatibility.
- Added optional camera hardware declaration so devices without cameras are not filtered out.
- Explicitly enabled resizable activities for phones, tablets and foldables.
- Enabled RTL support.
- Bumped app version to 2.19.6 / versionCode 51.

## Compatibility boundary
The app targets Android 17/API 37 while remaining installable down to Android 5.0/API 21.
Android 4.4/API 19 and earlier are intentionally not claimed as supported because the current 2026 AndroidX Activity Result dependency stack is not a safe compatibility target for this codebase.

## Security preserved
HTTPS-only networking, Supabase service isolation, Keystore-backed secrets, offline identity binding, and existing permission/runtime checks remain unchanged.
